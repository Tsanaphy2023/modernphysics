
import numpy as np
import matplotlib.pyplot as plt

# Constants
c = 3.00e8  # Speed of light in m/s

def lorentz_factor(v):
    """
    Calculates the Lorentz factor (gamma) for a given velocity v.
    v: velocity in m/s
    """
    if v >= c:
        raise ValueError("Velocity cannot be greater than or equal to the speed of light.")
    return 1 / np.sqrt(1 - (v**2 / c**2))

def time_dilation(t0, v):
    """
    Calculates the dilated time (t) for a given proper time (t0) and velocity (v).
    t0: proper time (time measured in the moving frame) in seconds
    v: velocity in m/s
    """
    gamma = lorentz_factor(v)
    return gamma * t0

def length_contraction(L0, v):
    """
    Calculates the contracted length (L) for a given proper length (L0) and velocity (v).
    L0: proper length (length measured in the rest frame) in meters
    v: velocity in m/s
    """
    gamma = lorentz_factor(v)
    return L0 / gamma

# --- Example Usage and Plotting ---

# Define a range of velocities as a fraction of c
velocities_fraction = np.linspace(0, 0.999, 1000) # From 0 to 0.999c
velocities = velocities_fraction * c

# Calculate Lorentz factor
gammas = [lorentz_factor(v) for v in velocities]

# Calculate Time Dilation (e.g., for a proper time of 1 second)
t0_example = 1 # seconds
dilated_times = [time_dilation(t0_example, v) for v in velocities]

# Calculate Length Contraction (e.g., for a proper length of 1 meter)
L0_example = 1 # meters
contracted_lengths = [length_contraction(L0_example, v) for v in velocities]

# Plotting Lorentz Factor
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.plot(velocities_fraction, gammas, color=\'blue\')
plt.xlabel(\'Velocity (v/c)\')
plt.ylabel(\'Lorentz Factor (γ)\')
plt.title(\'Lorentz Factor vs. Velocity\')
plt.grid(True)
plt.ylim(bottom=1)

# Plotting Time Dilation and Length Contraction
plt.subplot(1, 2, 2)
plt.plot(velocities_fraction, dilated_times, label=f\'Time Dilation (t0={t0_example}s)\', color=\'red\')
plt.plot(velocities_fraction, contracted_lengths, label=f\'Length Contraction (L0={L0_example}m)\' , color=\'green\')
plt.xlabel(\'Velocity (v/c)\')
plt.ylabel(\'Factor / Value\')
plt.title(\'Time Dilation and Length Contraction vs. Velocity\')
plt.legend()
plt.grid(True)
plt.ylim(bottom=0)

plt.tight_layout()
plt.savefig(\'special_relativity_plots.png\')
plt.show()

print("Python code for Special Relativity calculations and plots generated and saved as special_relativity_plots.png")

