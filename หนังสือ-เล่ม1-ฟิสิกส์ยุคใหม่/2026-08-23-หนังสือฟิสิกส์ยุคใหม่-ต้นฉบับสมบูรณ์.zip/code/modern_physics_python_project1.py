'''
import numpy as np
import matplotlib.pyplot as plt

# Constants
h = 6.626e-34  # Planck\'s constant
c = 3.000e8    # Speed of light
k = 1.381e-23  # Boltzmann constant

def planck_radiation(wavelength, T):
    """
    Calculates the spectral radiance of a black body using Planck\'s Law.
    wavelength: wavelength in meters
    T: temperature in Kelvin
    """
    a = 2 * h * c**2
    b = h * c / (wavelength * k * T)
    intensity = a / (wavelength**5 * (np.exp(b) - 1))
    return intensity

def rayleigh_jeans_radiation(wavelength, T):
    """
    Calculates the spectral radiance using Rayleigh-Jeans Law.
    wavelength: wavelength in meters
    T: temperature in Kelvin
    """
    intensity = (2 * c * k * T) / (wavelength**4)
    return intensity

# Wavelength range (in meters)
wavelengths = np.linspace(1e-9, 3e-6, 500) # From 1 nm to 3000 nm

# Temperatures to plot
T1 = 3000  # K
T2 = 5000  # K
T3 = 6000  # K (Sun\'s surface temperature approx)

plt.figure(figsize=(10, 6))

# Plot for T1
plt.plot(wavelengths * 1e9, planck_radiation(wavelengths, T1), label=f'Planck T={T1}K', color='blue')
plt.plot(wavelengths * 1e9, rayleigh_jeans_radiation(wavelengths, T1), '--', label=f'Rayleigh-Jeans T={T1}K', color='lightblue')

# Plot for T2
plt.plot(wavelengths * 1e9, planck_radiation(wavelengths, T2), label=f'Planck T={T2}K', color='red')
plt.plot(wavelengths * 1e9, rayleigh_jeans_radiation(wavelengths, T2), '--', label=f'Rayleigh-Jeans T={T2}K', color='pink')

# Plot for T3
plt.plot(wavelengths * 1e9, planck_radiation(wavelengths, T3), label=f'Planck T={T3}K', color='green')
plt.plot(wavelengths * 1e9, rayleigh_jeans_radiation(wavelengths, T3), '--', label=f'Rayleigh-Jeans T={T3}K', color='lightgreen')

plt.xlabel('Wavelength (nm)')
plt.ylabel('Spectral Radiance (W/m^3/sr)')
plt.title('Black Body Radiation: Planck vs Rayleigh-Jeans Law')
plt.legend()
plt.grid(True)
plt.ylim(bottom=0) # Ensure y-axis starts from 0
plt.xlim(left=0) # Ensure x-axis starts from 0
plt.tight_layout()
plt.savefig('black_body_radiation_plot.png')
plt.show()

print("Python code for Black Body Radiation plot generated and saved as black_body_radiation_plot.png")
'''
